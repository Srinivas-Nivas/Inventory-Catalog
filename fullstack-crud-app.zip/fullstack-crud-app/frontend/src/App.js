import React, { useState, useEffect } from "react";
import "./App.css";
import ItemService from "./services/ItemService";

function App() {
  const [items, setItems] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // Form state
  const [formData, setFormData] = useState({
    id: null,
    name: "",
    description: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  // Load all items on component mount
  useEffect(() => {
    loadItems();
  }, []);

  // Filter items when search term changes
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredItems(items);
    } else {
      const filtered = items.filter(
        (item) =>
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.description.toLowerCase().includes(searchTerm.toLowerCase()),
      );
      setFilteredItems(filtered);
    }
  }, [searchTerm, items]);

  const loadItems = async () => {
    try {
      setLoading(true);
      const response = await ItemService.getAllItems();
      setItems(response.data);
      setFilteredItems(response.data);
      setError("");
    } catch (err) {
      setError(
        "Failed to load items. Please make sure the backend server is running.",
      );
      console.error("Error loading items:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      setError("Name is required");
      return;
    }

    try {
      if (isEditing) {
        await ItemService.updateItem(formData.id, {
          name: formData.name,
          description: formData.description,
        });
      } else {
        await ItemService.createItem({
          name: formData.name,
          description: formData.description,
        });
      }

      resetForm();
      loadItems();
      setError("");
    } catch (err) {
      setError(
        `Failed to ${isEditing ? "update" : "create"} item. Please try again.`,
      );
      console.error("Error saving item:", err);
    }
  };

  const handleEdit = (item) => {
    setFormData({
      id: item.id,
      name: item.name,
      description: item.description || "",
    });
    setIsEditing(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        await ItemService.deleteItem(id);
        loadItems();
        setError("");
      } catch (err) {
        setError("Failed to delete item. Please try again.");
        console.error("Error deleting item:", err);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      id: null,
      name: "",
      description: "",
    });
    setIsEditing(false);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  return (
    <div className="App">
      <div className="header">
        <h1>📝 CRUD Application</h1>
        <p>Full Stack App with React, Spring Boot, and H2 Database</p>
      </div>

      {error && <div className="error">{error}</div>}

      <div className="item-form">
        <h2>{isEditing ? "✏️ Edit Item" : "➕ Add New Item"}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name *</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Enter item name"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Enter item description"
            />
          </div>

          <div className="button-group">
            <button type="submit" className="btn btn-primary">
              {isEditing ? "💾 Update Item" : "➕ Create Item"}
            </button>
            {isEditing && (
              <button
                type="button"
                className="btn btn-secondary"
                onClick={resetForm}
              >
                ✖️ Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="item-list">
        <h2>📋 Items List ({filteredItems.length})</h2>

        <div className="search-box">
          <input
            type="text"
            placeholder="🔍 Search items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {loading ? (
          <div className="loading">Loading items...</div>
        ) : filteredItems.length === 0 ? (
          <div className="empty-state">
            <p>
              No items found.{" "}
              {searchTerm
                ? "Try a different search term."
                : "Create your first item above!"}
            </p>
          </div>
        ) : (
          <div className="items-container">
            {filteredItems.map((item) => (
              <div key={item.id} className="item-card">
                <h3>{item.name}</h3>
                <p>{item.description || "No description provided"}</p>
                <div className="item-meta">
                  <div>Created: {formatDate(item.createdAt)}</div>
                  <div>Updated: {formatDate(item.updatedAt)}</div>
                </div>
                <div className="item-actions">
                  <button
                    className="btn btn-edit"
                    onClick={() => handleEdit(item)}
                  >
                    ✏️ Edit
                  </button>
                  <button
                    className="btn btn-delete"
                    onClick={() => handleDelete(item.id)}
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
