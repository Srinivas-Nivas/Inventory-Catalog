import axios from "axios";

const API_BASE_URL = "http://localhost:8080/api/items";

class ItemService {
  // Get all items
  getAllItems() {
    return axios.get(API_BASE_URL);
  }

  // Get item by ID
  getItemById(id) {
    return axios.get(`${API_BASE_URL}/${id}`);
  }

  // Create new item
  createItem(item) {
    return axios.post(API_BASE_URL, item);
  }

  // Update item
  updateItem(id, item) {
    return axios.put(`${API_BASE_URL}/${id}`, item);
  }

  // Delete item
  deleteItem(id) {
    return axios.delete(`${API_BASE_URL}/${id}`);
  }

  // Search items
  searchItems(keyword) {
    return axios.get(`${API_BASE_URL}/search`, {
      params: { keyword },
    });
  }
}

export default new ItemService();
