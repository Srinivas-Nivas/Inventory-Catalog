#!/bin/bash
echo "=========================================="
echo "  FULLSTACK CRUD APPLICATION STRUCTURE"
echo "=========================================="
echo ""
echo "📁 /tmp/fullstack-crud-app/"
echo "│"
echo "├── 📂 backend/"
echo "│   ├── 📂 src/"
echo "│   │   ├── 📂 main/"
echo "│   │   │   ├── 📂 java/com/example/crud/"
echo "│   │   │   │   ├── 📄 CrudApplication.java"
echo "│   │   │   │   ├── 📂 config/"
echo "│   │   │   │   │   └── 📄 CorsConfig.java"
echo "│   │   │   │   ├── 📂 controller/"
echo "│   │   │   │   │   └── 📄 ItemController.java"
echo "│   │   │   │   ├── 📂 model/"
echo "│   │   │   │   │   └── 📄 Item.java"
echo "│   │   │   │   ├── 📂 repository/"
echo "│   │   │   │   │   └── 📄 ItemRepository.java"
echo "│   │   │   │   └── 📂 service/"
echo "│   │   │   │       └── 📄 ItemService.java"
echo "│   │   │   └── 📂 resources/"
echo "│   │   │       └── 📄 application.properties"
echo "│   │   └── 📂 test/java/"
echo "│   ├── 🐳 Dockerfile"
echo "│   ├── 📄 pom.xml"
echo "│   └── 📄 .gitignore"
echo "│"
echo "├── 📂 frontend/"
echo "│   ├── 📂 public/"
echo "│   │   └── 📄 index.html"
echo "│   ├── 📂 src/"
echo "│   │   ├── 📂 services/"
echo "│   │   │   └── 📄 ItemService.js"
echo "│   │   ├── 📄 App.js"
echo "│   │   ├── 📄 App.css"
echo "│   │   ├── 📄 index.js"
echo "│   │   └── 📄 index.css"
echo "│   ├── 🐳 Dockerfile"
echo "│   ├── ⚙️  nginx.conf"
echo "│   ├── 📄 package.json"
echo "│   └── 📄 .gitignore"
echo "│"
echo "├── 🐳 docker-compose.yml"
echo "├── 📄 .gitignore"
echo "├── 🚀 start.sh"
echo "├── 📖 README.md"
echo "├── 📋 PROJECT_SUMMARY.md"
echo "├── ⚡ QUICK_REFERENCE.md"
echo "├── 🏗️  ARCHITECTURE.md"
echo "├── 📁 DIRECTORY_STRUCTURE.md"
echo "└── 📝 COMPLETE_FILE_LISTING.md"
echo ""
echo "=========================================="
echo "TOTAL: 30 files across 16 directories"
echo "=========================================="
echo ""
echo "To verify all files exist, run:"
echo "  ./show-structure.sh verify"
echo ""

if [ "$1" == "verify" ]; then
    echo "Verifying files..."
    echo ""
    
    count=0
    
    # Backend files
    for file in backend/pom.xml \
                backend/Dockerfile \
                backend/src/main/java/com/example/crud/CrudApplication.java \
                backend/src/main/java/com/example/crud/config/CorsConfig.java \
                backend/src/main/java/com/example/crud/controller/ItemController.java \
                backend/src/main/java/com/example/crud/model/Item.java \
                backend/src/main/java/com/example/crud/repository/ItemRepository.java \
                backend/src/main/java/com/example/crud/service/ItemService.java \
                backend/src/main/resources/application.properties; do
        if [ -f "$file" ]; then
            echo "✅ $file"
            ((count++))
        else
            echo "❌ $file MISSING"
        fi
    done
    
    # Frontend files
    for file in frontend/package.json \
                frontend/Dockerfile \
                frontend/nginx.conf \
                frontend/public/index.html \
                frontend/src/App.js \
                frontend/src/App.css \
                frontend/src/index.js \
                frontend/src/index.css \
                frontend/src/services/ItemService.js; do
        if [ -f "$file" ]; then
            echo "✅ $file"
            ((count++))
        else
            echo "❌ $file MISSING"
        fi
    done
    
    # Root files
    for file in docker-compose.yml \
                README.md \
                PROJECT_SUMMARY.md \
                QUICK_REFERENCE.md \
                ARCHITECTURE.md \
                DIRECTORY_STRUCTURE.md \
                COMPLETE_FILE_LISTING.md; do
        if [ -f "$file" ]; then
            echo "✅ $file"
            ((count++))
        else
            echo "❌ $file MISSING"
        fi
    done
    
    echo ""
    echo "=========================================="
    echo "Verified: $count files ✅"
    echo "=========================================="
fi
